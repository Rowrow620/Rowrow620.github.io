
package com.example.Calculator;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/*-------------------------------------------------------------------------------------------
 * Author: Juan Sanchez
 * Date: 10/06/2024
 * Version: 1.3 Milestone Four Enhancements Three
 * Class: CS499
 * -------------------------------------------------------------------------------------------
 * Description of Program: This program coded in Java is a multipurpose calculator application that uses a database to store the user's past operations.
 * Currently, it does not store the sorting operation, but all other operations are stored.
 * The application prompts the user with a welcome message as well as asking the user to choose one of ten options (0-9) from the display menu.
 * Options 1-7 involve multiple arithmemitic options in which the user will either be prompted to enter 1 or 2 numbers for all except the Square root operation that only takes one number.
 * Option 8 is a sorting numbers algorithm in which the user will be prompted to enter as many numbers as they choose. After they do, they will be
 * asked to choose sorting in ascending or descending order. The last option in the first table is to exit.
 * After, the database options will be listed. Currently the only option is to view the past 10 operations.
 *
 * Notes on changes:
 * -----------------
 * 1.0 (original)
 * The code was converted from binary -> assembly -> C++ prior to the final conversion to Java in Milestone 1 (Version 1.1).
 * Originally, it was a simple calculator app with only options 1-3 related to artihmetic and 4 being exit.
 *
 * 1.1
 * In versions 1.1, we created the abstract class operations as well as used inheritance to create the rest of the operation classes.
 * I added exception handling by throwing an arithmetic exception during the operation process in case of any errors.
 * Added data validation to ensure that the user is entering a number.
 *
 * 1.2
 * Created a package for the project as well as seperated all classes out of the Main file. Changed from
 * storing the user inputs in integers to storing them in hashmaps for the operations. Added Modulus, Power, and Square Root options.
 * For the square root option, the user will only need to enter one number and they receive its square root.
 * Added a sorting choice in which the user will input any amount of numbers into an array list, choose either ascending or
 * descending order, and then receive the appropriate list based on their choices. In the new data structures, doubles are used instead of Integers.
 *
 * 1.3
 * Implemented a database through SQLite3. Verifies connection to the database and that the database exists.
 * Introduced a feature that stores all arithmetic operation results (Addition, Subtraction, Multiplication, Division, Modulus, Power, Square Root) into the database.
 * Added a functionality to retrieve and display the user's last 10 operations from the database, allowing users to view their recent calculation history.
 * The sorting operation (Option 8) is not stored in the database due to the dynamic nature of input and sorting requirements.
 * Enhanced the display menu to include an option (Option 0) for users to view past operations.
 * Operations stored include the type of operation, the operands, and the result.
 * Limited the history display to the 10 most recent operations using SQL `ORDER BY` and `LIMIT` clauses.
 *
 *
 /*
* Time Complexity Overview:
* -------------------------
* Arithmetic Operations (Addition, Subtraction, Multiplication, Division, Modulus, Power, Square Root):
* These operations are constant time operations, i.e., O(1) since they only involve basic arithmetic calculations on two operands.
*
* Insertion into Database (insertOperation method):
* Inserting an operation into the SQLite database also occurs in constant time, O(1), as it inserts a single record regardless of its size.
* Database connections and execution of SQL commands are usually O(1)
*
* Retrieving Past Operations (viewPastOperations method):
* Retrieving the last 10 operations involves querying the database with an ORDER BY clause and a LIMIT, which can be considered O(1) for a fixed number of operations.
*The time complexity may increase if the database grows larger, but since the result set is limited to the last 10 entries, the retrieval time remains O(1).
*
* Sorting Operation (Option 8):
* Sorting the input list of numbers depends on the sorting algorithm used
* If a built-in sorting method such as Timsort (Java's default sorting algorithm) is used, the time complexity is O(n log n), where n is the number of elements in the input list
*
* Overall:
* The arithmetic operations and database interactions are efficient and constant-time, O(1)
* The sorting operation (Option 8) is the most computationally expensive, with O(n log n) time complexity
*
* --------------------------------------------------------------------------------------------*/


public class Main {

    // establishes connection to SQLite
    private static Connection connect() {
        String url = "jdbc:sqlite:calculator.db"; // SQLite db file
        Connection conn = null;
        try {
            // loads the SQLite JDBC driver
            Class.forName("org.sqlite.JDBC");

            // establish a connection with the db
            conn = DriverManager.getConnection(url);
            System.out.println("Connected to the database.");
        } catch (SQLException e) {
            System.out.println("SQL error: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("SQLite JDBC Driver was not found.");
            e.printStackTrace();
        }
        return conn;
    }

    // creates operations table in SQLite database
    private static void createTable() {
        // SQL that creates a new table
        String sql = "CREATE TABLE IF NOT EXISTS operations ("
                + " id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + " operation TEXT NOT NULL,"
                + " operand1 REAL,"
                + " operand2 REAL,"
                + " result REAL"
                + ");";

        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Table 'operations' created or already exists.");
        } catch (SQLException e) {
            System.out.println("SQL error during table creation: " + e.getMessage());
        }
    }

    // inserts an operation into the SQLite database
    private static void insertOperation(String operation, double operand1, double operand2, double result) {
        String sql = "INSERT INTO operations(operation, operand1, operand2, result) VALUES(?,?,?,?)";

        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, operation);
            pstmt.setDouble(2, operand1);
            pstmt.setDouble(3, operand2);
            pstmt.setDouble(4, result);
            pstmt.executeUpdate();
            System.out.println("Operation saved to database.");
        } catch (SQLException e) {
            System.out.println("Error during insertion: " + e.getMessage());
        }
    }

    // UPDATE 1.3: display the last 10 past operations
    // Needed to get operation 0 in the displaymenu to work
    private static void viewPastOperations() {
        String sql = "SELECT id, operation, operand1, operand2, result FROM operations "
                + "ORDER BY id DESC LIMIT 10";  // gets only the last 10 operations

        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet resultSet = stmt.executeQuery(sql)) {

            System.out.println("ID | Operation | Operand1 | Operand2 | Result");
            System.out.println("---------------------------------------------");

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String operation = resultSet.getString("operation");
                double operand1 = resultSet.getDouble("operand1");
                double operand2 = resultSet.getDouble("operand2");
                double result = resultSet.getDouble("result");
                System.out.printf("%d | %s | %.2f | %.2f | %.2f%n", id, operation, operand1, operand2, result);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving past operations: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // hashmap operationsMap to be used to store operations
        Map<Integer, Operation> operationsMap = new HashMap<>();
        operationsMap.put(1, new Addition());
        operationsMap.put(2, new Subtraction());
        operationsMap.put(3, new Multiplication());
        operationsMap.put(4, new Division());
        operationsMap.put(5, new Modulus());
        operationsMap.put(6, new Power());
        operationsMap.put(7, new SquareRoot());
        SortOperation sortOperation = new SortOperation();

        createTable();

        int userChoice;

        // loops displayMenu until user chooses to exit
        while (true) {
            DisplayMenu.showMenu();

            userChoice = DisplayMenu.getValidInteger(scanner, "Enter your choice (0-9):");
            // closes program if user enters '9'
            if (userChoice == 9) {
                System.out.println("Exiting program."); // closes program
                break;
            }

            // View past operations (new option 10)
            if (userChoice == 0) {
                viewPastOperations();
                continue;
            }

            if (userChoice == 8) {
                List<Double> numbers = DisplayMenu.getNumberList(scanner);
                System.out.print("Sort in ascending order? (y/n): ");
                boolean ascending = scanner.next().equalsIgnoreCase("y");
                List<Double> sortedNumbers = sortOperation.performSortOperation(numbers, ascending);
                System.out.println("Sorted numbers: " + sortedNumbers);
            } else if (!operationsMap.containsKey(userChoice)) {
                System.out.println("Invalid input. Please enter a number between 1 and 9.");
                continue;
            } else {
                double n1 = DisplayMenu.getValidInteger(scanner, "Enter the first number: ");
                double n2 = (userChoice == 7) ? 0 : DisplayMenu.getValidInteger(scanner, "Enter the second number: ");
                Operation operation = operationsMap.get(userChoice);
                try {
                    double result = operation.performOperation(n1, n2);
                    System.out.println("Result: " + result);

                    // Added 1.3: stores the operation in the database
                    insertOperation(operation.getClass().getSimpleName(), n1, n2, result);
                } catch (ArithmeticException e) {
                    System.out.println(e.getMessage());
                }
            }

            // ask if the user wants to continue
            System.out.print("Continue? (y/n): ");
            String continueChoice = scanner.next().toLowerCase();
            if (!continueChoice.equals("y")) {
                System.out.println("Exiting program.");
                break;
            }
        }

        scanner.close();
    }
}
